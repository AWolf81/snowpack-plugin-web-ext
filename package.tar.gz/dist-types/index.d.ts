import type { SnowpackPluginFactory } from "snowpack";
declare const plugin: SnowpackPluginFactory;
export default plugin;
